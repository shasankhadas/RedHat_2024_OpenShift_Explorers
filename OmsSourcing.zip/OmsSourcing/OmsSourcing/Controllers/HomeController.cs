﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using OmsSourcing.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace OmsSourcing.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        // private readonly IW<HomeController> _logger;
        public static DataTable activeDGVTable = new DataTable();
        private readonly string _pgDBConnectionString = string.Empty;
        private readonly string _itemAPI = string.Empty;
        private readonly string _avlAPI = string.Empty;
        private readonly string _weatherAPI = string.Empty;
        //private GetAPIDataModel getAPIData = new GetAPIDataModel();
        public HomeController(ILogger<HomeController> logger, IOptions<ConfigurationSettings> optionsAccessor)
        {
            _logger = logger;
            _itemAPI = optionsAccessor.Value.ItemAPI;
            _avlAPI = optionsAccessor.Value.AvlAPI;
            _weatherAPI = optionsAccessor.Value.WeatherAPI;
        }

        public IActionResult Index()
        {
            activeDGVTable = new DataTable();
            return View();
        }

        [HttpPost]
        public ActionResult Index(IpData model)
        {

            if (model.txtQty != null)
            {
                string itemID = model.txtQtyItem;
                string qty = model.txtQty;
                getAvailability(itemID, qty);
                IList<OmsInventory> items = activeDGVTable.AsEnumerable().Select(row =>
                    new OmsInventory
                    {
                        ItemId = row.Field<string>("ItemId"),
                        ItemDesc = row.Field<string>("ItemDesc"),
                        ItemImage = row.Field<string>("ItemImage"),
                        NodeKey = row.Field<string>("NodeKey"),
                        Qty = row.Field<string>("Qty"),
                        AvlQty = row.Field<string>("AvlQty"),
                        ShipFrom = row.Field<string>("ShipFrom"),
                        EstDelDate = row.Field<string>("EstDelDate"),
                        SuppyType = row.Field<string>("SuppyType"),
                        InsightComments = row.Field<string>("InsightComments")

                    }).ToList();


                ViewBag.OmsInventory = items;
            }
            else
            {
                string _txtItemSearch = model.txtItemSearch;
                CreateDataTableForGV();
                getItemDetail(_txtItemSearch);

                IList<OmsInventory> items = activeDGVTable.AsEnumerable().Select(row =>
                    new OmsInventory
                    {
                        ItemId = row.Field<string>("ItemId"),
                        ItemDesc = row.Field<string>("ItemDesc"),
                        ItemImage = row.Field<string>("ItemImage"),
                        NodeKey = row.Field<string>("NodeKey"),
                        Qty = row.Field<string>("Qty"),
                        AvlQty = row.Field<string>("AvlQty"),
                        ShipFrom = row.Field<string>("ShipFrom"),
                        EstDelDate = row.Field<string>("EstDelDate"),
                        SuppyType = row.Field<string>("SuppyType"),
                        InsightComments = row.Field<string>("InsightComments")

                    }).ToList();
                ViewBag.OmsInventory = items;
            }
            return View();
        }

        private static void CreateDataTableForGV()
        {
            if (activeDGVTable.Columns.Count < 1)
            {
                activeDGVTable = new DataTable();
                activeDGVTable.Clear();
                activeDGVTable.Columns.Add("ItemId");
                activeDGVTable.Columns.Add("ItemDesc");
                activeDGVTable.Columns.Add("ItemImage");
                activeDGVTable.Columns.Add("NodeKey");
                activeDGVTable.Columns.Add("InventoryKey");
                activeDGVTable.Columns.Add("Qty");
                activeDGVTable.Columns.Add("AvlQty");
                activeDGVTable.Columns.Add("ShipFrom");
                activeDGVTable.Columns.Add("EstDelDate");
                activeDGVTable.Columns.Add("SuppyType");
                activeDGVTable.Columns.Add("InsightComments");
            }
        }

        private void AddItemDetailsDataForGV(string resp)
        {
            if (resp.Length > 0)
            {
                JArray jsonResp = JArray.Parse(resp);
                foreach (JObject objx in jsonResp.Children<JObject>())
                {
                    DataRow Itemdtls = activeDGVTable.NewRow();
                    foreach (JProperty singleProp in objx.Properties())
                    {
                        if (singleProp.Name.Contains("itemDesc")) { Itemdtls["ItemDesc"] = singleProp.Value.ToString(); }
                        if (singleProp.Name.Contains("itemImage")) { Itemdtls["ItemImage"] = singleProp.Value.ToString(); }
                        if (singleProp.Name.Contains("nodeKey")) { Itemdtls["NodeKey"] = singleProp.Value.ToString(); }
                        if (singleProp.Name.Contains("itemId")) { Itemdtls["ItemId"] = singleProp.Value.ToString(); }
                    }
                    activeDGVTable.Rows.Add(Itemdtls);
                }
            }
            else
            {
                DataRow Itemdtls = activeDGVTable.NewRow();
                Itemdtls["ItemDesc"] = "Item Desc";
                Itemdtls["ItemImage"] = "Item Image";
                Itemdtls["NodeKey"] = "12334";
                Itemdtls["ItemId"] = "10104122";
                activeDGVTable.Rows.Add(Itemdtls);
            }
            // BindGridVW();
        }

        private void UpdateDataForAvlGV(string resp, string ipQty)
        {
            JArray jsonResp = JArray.Parse(resp);
            var longitude = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("longitude");
            var latitude = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("latitude");
            var transitDay = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("transitDay");
            string tranDate = DateTime.Today.AddDays(Convert.ToInt32(transitDay)).ToString("yyyy-MM-dd");

            string weatherReap = GetWeatherInformation(latitude, longitude);
            var jsonFiterResp = JObject.Parse(weatherReap)["list"].Children();
            //var filterWeatherList = jsonFiterResp.Where(t => t["dt_txt"].ToString().Contains("2024-09-19")).ToList();
            var filterWeatherList = jsonFiterResp.Where(t => t["dt_txt"].ToString().Contains(tranDate) && t["weather"][0]["description"].ToString().Contains("heavy intensity rain")).ToList();

            if (filterWeatherList.Count > 0)
            {
                var longitude1 = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("longitude");
                var latitude1 = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("latitude");
                var transitDay1 = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("transitDay");
                string tranDate1 = DateTime.Today.AddDays(Convert.ToInt32(transitDay1)).ToString("yyyy-MM-dd");
                string weatherReap1 = GetWeatherInformation(latitude1, longitude1);
                var jsonFiterResp1 = JObject.Parse(weatherReap1)["list"].Children();
                var filterWeatherList1 = jsonFiterResp1.Where(t => t["dt_txt"].ToString().Contains(tranDate1) && t["weather"][0]["description"].ToString().Contains("heavy intensity rain")).ToList();
                if (filterWeatherList1.Count == 0)
                {
                    var ItemId = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("itemID");
                    foreach (DataRow rowNode in activeDGVTable.Rows)
                    {
                        if (rowNode["ItemId"].ToString() == ItemId)
                        {
                            var suppyType = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("suppyType");
                            var qty = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("qty");
                            var node_name = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("nodeName");
                            var nodeKey = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("nodeKey");
                            var area = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "2").Value<string>("area");

                            rowNode["NodeKey"] = nodeKey;
                            rowNode["Qty"] = ipQty;
                            rowNode["AvlQty"] = qty;
                            rowNode["ShipFrom"] = node_name + ", " + area; 
                            rowNode["EstDelDate"] = tranDate1;
                            rowNode["SuppyType"] = suppyType;
                            rowNode["InsightComments"] = "Sourcing from secondary location as primary location having rainy weather forecast";
                        }
                    }
                }

            }
            else
            {
                var ItemId = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("itemID");
                foreach (DataRow rowNode in activeDGVTable.Rows)
                {
                    if (rowNode["ItemId"].ToString() == ItemId)
                    {
                        var suppyType = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("suppyType");
                        var qty = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("qty");
                        var node_name = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("nodeName");
                        var nodeKey = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("nodeKey");
                        var area = jsonResp.FirstOrDefault(x => x.Value<string>("priority") == "1").Value<string>("area");
                        rowNode["NodeKey"] = nodeKey;
                        rowNode["Qty"] = ipQty;
                        rowNode["AvlQty"] = qty;
                        rowNode["ShipFrom"] = node_name + ", " +  area;
                        rowNode["EstDelDate"] = tranDate;
                        rowNode["SuppyType"] = suppyType;
                        rowNode["InsightComments"] = "Sourcing from primary location with good weather forecast";
                    }
                }

            }
            //BindGridVW();
        }



        private void getItemDetail(string ItemID)
        {

            string url = _itemAPI + "?ItemID=" + ItemID;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            string ItemData = @"{{""name"":""ItemValue""}}";
            ItemData.Replace("ItemValue", ItemID);
            request.ContentType = "application/json";
            try
            {
                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string response = responseReader.ReadToEnd();
                Console.Out.WriteLine(response);
                responseReader.Close();

                if (response == "[]")
                {
                    using (StreamReader r = new StreamReader("ItemData.json"))
                    {
                        response = r.ReadToEnd();
                    }
                }
                AddItemDetailsDataForGV(response);
            }
            catch (Exception e)
            {
                Console.Out.WriteLine("-----------------");
                Console.Out.WriteLine(e.Message);
            }

        }
        private void getAvailability(string ItemID, string qty)
        {
            string url = _avlAPI + "?ItemID=" + ItemID + "&Qty=" + qty;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.ContentType = "application/json";
            try
            {
                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string response = responseReader.ReadToEnd();
                Console.Out.WriteLine(response);
                responseReader.Close();
                if (response == "[]")
                {
                    throw new ArgumentException("getAvailability returning null");
                }
                UpdateDataForAvlGV(response, qty);
                Console.Out.WriteLine("UpdateDataForAvlGV from Response");
            }
            catch (Exception e)
            {
                Console.Out.WriteLine("-----------------");
                string json = string.Empty;
                using (StreamReader r = new StreamReader("InvData.json"))
                {
                    json = r.ReadToEnd();
                }
                //string json = File.ReadAllText(@"C:\Users\04623C744\source\repos\OmsSmartSourcing\OmsSmartSourcing\InvData.json");
                UpdateDataForAvlGV(json, qty);
                Console.Out.WriteLine("UpdateDataForAvlGV from Catch");
                Console.Out.WriteLine(e.Message);
            }
        }


        private string GetWeatherInformation(string lat, string lon)
        {
            string resp = "";
            string url = _weatherAPI + "?lat=" + lat + "&lon=" + lon + "&appid=3150fb5580c81a47503ba3b928ba0deb";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.ContentType = "application/json";
            try
            {
                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string response = responseReader.ReadToEnd();
                Console.Out.WriteLine(response);
                responseReader.Close();
                resp = response;
            }
            catch (Exception e)
            {
                Console.Out.WriteLine("-----------------");
                Console.Out.WriteLine(e.Message);
            }
            return resp;
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
