﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OmsSourcing.Models
{
    public class IpData
    {
        public string txtItemSearch { get; set; }
        public string txtQtyItem { get; set; }
        public string txtQty { get; set; }
      
    }
}
