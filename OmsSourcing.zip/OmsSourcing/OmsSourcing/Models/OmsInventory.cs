﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OmsSourcing.Models
{
    public class OmsInventory
    {
        public string ItemId { get; set; }
        public string ItemDesc { get; set; }
        public string ItemImage { get; set; }
        public string NodeKey { get; set; }
        public string InventoryKey { get; set; }
        public string Qty { get; set; }
        public string AvlQty { get; set; }
        public string ShipFrom { get; set; }
        public string EstDelDate { get; set; }
        public string SuppyType { get; set; }
        public string InsightComments { get; set; }
    }
}
