﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OmsSourcing
{
    public class ConfigurationSettings
    {
        public string PGConnectionString { get; set; }
        public string ItemAPI { get; set; }
        public string AvlAPI { get; set; }
        public string WeatherAPI { get; set; }
    }
}
