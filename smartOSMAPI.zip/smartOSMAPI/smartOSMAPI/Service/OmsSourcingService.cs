﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace smartOSMAPI.Service
{
    public partial class OmsSourcingService : IOmsSourcingService
    {
        private readonly string _pgDBConnectionString = string.Empty;
        private readonly string _imageProcessorAPI = string.Empty;

        public OmsSourcingService(IOptions<ConfigurationSettings> optionsAccessor)
        {
            _pgDBConnectionString = optionsAccessor.Value.PGConnectionString;
        }

        //public List<OmsNode> getItemDetailList()
        //{
        //    var connectionString = _pgDBConnectionString;
        //    NpgsqlConnection con = new NpgsqlConnection(connectionString);
        //    List<OmsNode> list = new List<OmsNode>();
        //    var query = @"SELECT id, firstname, lastname, email, createtime FROM public.customer;";

        //    DataTable dt = new DataTable();

        //    NpgsqlCommand Lcmd = new NpgsqlCommand(query, con);

        //    con.Open();
        //    using (NpgsqlDataAdapter comm = new NpgsqlDataAdapter(query, con))
        //    {
        //        // Adapter fill table function
        //        comm.Fill(dt);
        //    }
        //    con.Close();
        //    // list = dt.AsEnumerable().ToList();
        //    return list;
        //}

        //public List<OmsNode> getAvailabilityList()
        //{
        //    var connectionString = _pgDBConnectionString;
        //    NpgsqlConnection con = new NpgsqlConnection(connectionString);
        //    List<OmsNode> list = new List<OmsNode>();
        //    var query = @"SELECT id, firstname, lastname, email, createtime FROM public.customer;";

        //    DataTable dt = new DataTable();

        //    NpgsqlCommand Lcmd = new NpgsqlCommand(query, con);

        //    con.Open();
        //    using (NpgsqlDataAdapter comm = new NpgsqlDataAdapter(query, con))
        //    {
        //        // Adapter fill table function
        //        comm.Fill(dt);
        //    }
        //    con.Close();
        //    // list = dt.AsEnumerable().ToList();
        //    return list;
        //}

        //public List<OmsNode> getNodeDetailList()
        //{
           

        //        var connectionString = _pgDBConnectionString;
        //        NpgsqlConnection con = new NpgsqlConnection(connectionString);
        //        List<OmsNode> list = new List<OmsNode>();
        //        var query = @"SELECT id, firstname, lastname, email, createtime FROM public.customer;";

        //        DataTable dt = new DataTable();

        //        NpgsqlCommand Lcmd = new NpgsqlCommand(query, con);

        //        con.Open();
        //        using (NpgsqlDataAdapter comm = new NpgsqlDataAdapter(query, con))
        //        {
        //            // Adapter fill table function
        //            comm.Fill(dt);
        //        }
        //        con.Close();
        //       // list = dt.AsEnumerable().ToList();
        //        return list;
            
            
        //}

    }

    public interface IOmsSourcingService
    {
        //List<OmsNode> getItemDetailList();
        //List<OmsNode>  getAvailabilityList();
        //List<OmsNode> getNodeDetailList();
        
    }
}
