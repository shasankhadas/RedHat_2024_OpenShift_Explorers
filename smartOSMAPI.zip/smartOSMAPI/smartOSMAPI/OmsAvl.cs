﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace smartOSMAPI
{
    public class OmsAvl

    {
        public List<OmsInventory> OmsInventoryList { get; set; }
        //public List<OmsNode> OmsNodeList { get; set; }

    }
}
