﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace smartOSMAPI
{
    public class OmsNode
    {
        public string NodeKey { get; set; }
        public string NodeName { get; set; }
        public string NodeType { get; set; }
        public decimal Longitude { get; set; }
        public decimal Latitude { get; set; }
        public string Area { get; set; }

    }
}
