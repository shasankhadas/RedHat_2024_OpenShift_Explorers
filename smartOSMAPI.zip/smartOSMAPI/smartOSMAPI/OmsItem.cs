﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace smartOSMAPI
{
    public class OmsItem

    {
        public string NodeKey { get; set; }
        public string ItemId { get; set; }
        public string ItemDesc { get; set; }
        public string ItemImage { get; set; }


    }
}
