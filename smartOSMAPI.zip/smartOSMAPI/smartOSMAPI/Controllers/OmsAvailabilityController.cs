﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RestSharp;
using Npgsql;
using System.Text.Json;
using Newtonsoft.Json;
using smartOSMAPI.Service;
using System.Data;
using Microsoft.AspNetCore.Cors;
using Microsoft.Extensions.Options;
using System.IO;

namespace smartOSMAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]

    public class OmsAvailabilityController : ControllerBase
    {
        private readonly string _pgDBConnectionString = string.Empty;

        private readonly ILogger<OmsAvailabilityController> _logger;

        public OmsAvailabilityController(ILogger<OmsAvailabilityController> logger, IOptions<ConfigurationSettings> optionsAccessor)
        {
            _logger = logger;
            _pgDBConnectionString = optionsAccessor.Value.PGConnectionString;
        }



        [HttpGet("getAvailability")]
        public List<OmsInventory> getAvailabilityItems(string ItemID, string Qty)
        {
            List<OmsInventory> Invlist = new List<OmsInventory>();
            try
            {
                NpgsqlConnection con = new NpgsqlConnection(_pgDBConnectionString);

                var query = "Select node_key , quantity , transit_day , supply_type , priority from OMS_INVENTORY where item_id = '" + ItemID + "' and quantity >= " + Qty + ";";
                var query1 = "select * from OMS_NODE;";
                Console.Write(" query 1 " + query);
                DataTable dtInv = new DataTable();
                DataTable dtNod = new DataTable();
                NpgsqlCommand Lcmd = new NpgsqlCommand(query, con);
                con.Open();
                using (NpgsqlDataAdapter comm = new NpgsqlDataAdapter(query, con))
                {
                    comm.Fill(dtInv);
                }
                Console.Write(" query 2 " + query1);
                using (NpgsqlDataAdapter comm = new NpgsqlDataAdapter(query1, con))
                {
                    comm.Fill(dtNod);
                }
                con.Close();
                int count = dtInv.Rows.Count;
                Console.Write("Row Count Inventory " + count + " ");
              
                foreach (DataRow row in dtInv.Rows)
                {
                    OmsInventory OI = new OmsInventory();
                    OI.ItemID = ItemID;
                    OI.NodeKey = row["node_key"].ToString();
                    OI.Qty = row["quantity"].ToString();
                    OI.TransitDay = Convert.ToInt32(row["transit_day"].ToString());
                    OI.SuppyType = row["supply_type"].ToString();
                    OI.Priority = row["priority"].ToString();
                    foreach (DataRow rowNode in dtNod.Rows)
                    {
                        if (rowNode["node_key"].ToString() == OI.NodeKey) {
                            OI.NodeName = rowNode["node_name"].ToString();
                            OI.NodeType = rowNode["node_type"].ToString();
                            OI.Longitude = Convert.ToDecimal(rowNode["longitude"].ToString());
                            OI.Latitude = Convert.ToDecimal(rowNode["latitude"].ToString());
                            OI.Area = rowNode["area"].ToString().Trim(); ;
                        }
                    }
                    Invlist.Add(OI);
                    Console.Write("Invlist added");
                }
                
                //int countNod = dtNod.Rows.Count;
                //Console.Write("Row Count Node " + countNod + " ");
                //List<OmsNode> nodelist = new List<OmsNode>();
                //foreach (DataRow row in dtNod.Rows)
                //{
                //    OmsNode OND = new OmsNode();
                //    OND.NodeKey = row["node_key"].ToString();
                //    OND.NodeName = row["node_name"].ToString();
                //    OND.NodeType = row["node_type"].ToString();
                //    OND.Longitude = Convert.ToDecimal(row["longitude"].ToString());
                //    OND.Latitude = Convert.ToDecimal(row["latitude"].ToString());
                //    OND.Area = row["area"].ToString(); ;
                //    nodelist.Add(OND);
                //    Console.Write("nodelist added");
                //}
                //if (nodelist.Count > 0) { _omsAvl.OmsNodeList = nodelist; }

            }
            catch (Exception e)
            {
                Console.Write(e.Message.ToString());
            }
            return Invlist;
        }

    }
}
