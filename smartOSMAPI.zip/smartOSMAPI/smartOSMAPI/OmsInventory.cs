﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace smartOSMAPI
{
    public class OmsInventory

    {
        public string  InventoryKey { get; set; }
        public string   ItemID{ get; set; }
        public string NodeKey { get; set; }
        public string Qty { get; set; }
        public int  TransitDay { get; set; }
        public string  SuppyType { get; set; }
        public string   Priority { get; set; }
        public string NodeName { get; set; }
        public string NodeType { get; set; }
        public decimal Longitude { get; set; }
        public decimal Latitude { get; set; }
        public string Area { get; set; }

    }
}
